package assignment3;

import java.util.ArrayList;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.TimeUnit;

public class Fika {
	private ConcurrentLinkedQueue<Worker> coffeeQueue = new ConcurrentLinkedQueue<>(); // A queue holds workers who are
																						// waiting for coffee
	private ArrayList<Worker> persons = new ArrayList<>(); // An ArrayList of workers who take a fika break
	private CoffeeMachine coffeeMachine; // Object for making coffee
	private final int SIMULATION_TIME_SECONDS = 20; // Simulation time 20 seconds

	public Fika() {
		initializeWorkers(); // Create objects for simulation
		coffeeMachine = new CoffeeMachine(coffeeQueue); // Create object for coffee machine
	}

	private void initializeWorkers() { // initializing workers
		persons.add(new Worker("Azhar", coffeeQueue));
		persons.add(new Worker("Raman", coffeeQueue));
		persons.add(new Worker("Jonab", coffeeQueue));
		persons.add(new Worker("Tommy", coffeeQueue));
		persons.add(new Worker("Simon", coffeeQueue));
		persons.add(new Worker("Rohan", coffeeQueue));
	}

	public void startSimulation() {
		startThreads();
		waitForSimulationEnd();
		interruptThreads();
	}

	private void startThreads() {
		coffeeMachine.start(); // Start the coffee machine thread

		// Iterate through each worker in the persons ArrayList
		for (Worker worker : persons) {
			worker.start(); // Start each worker thread
		}
	}

	private void waitForSimulationEnd() {
		try {
			TimeUnit.SECONDS.sleep(SIMULATION_TIME_SECONDS);// Pause execution for the duration of the simulation time
		} catch (InterruptedException e) {
			System.out.println("Simulation interrupted.");
		}
		System.out.println("Simulation Ending");
	}

	private void interruptThreads() {
		coffeeMachine.interrupt(); // Interrupt the coffee machine thread
		for (Worker worker : persons) {
			worker.interrupt(); // Interrupt all worker threads
		}
	}

	public static void main(String[] args) {
		Fika fika = new Fika();
		fika.startSimulation();
	}
}
