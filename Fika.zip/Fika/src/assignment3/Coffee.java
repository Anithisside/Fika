package assignment3;

import java.util.Random;

public class Coffee { // The Coffee class represents a type of coffee.

	private static Random random = new Random(); // Random number generator for energy.

	private int energy;

	private String type;

	public Coffee(String type, int minEnergy, int maxEnergy) { // Constructs a new Coffee object with the given type and
																// energy range.

		this.type = type;
		this.energy = random.nextInt(maxEnergy - minEnergy + 1) + minEnergy; // Set the coffee's energy to a random
																				// value between the given minEnergy and
																				// maxEnergy

	}

	public int getEnergy() { // Retrieves the energy level of the coffee.

		return this.energy;
	}

	public String getType() { // Retrieves the type of the coffee.

		return this.type;
	}
}
