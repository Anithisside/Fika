package assignment3;

import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

public class CoffeeMachine extends Thread {
	private volatile boolean active = true;
	private final ConcurrentLinkedQueue<Worker> coffeeQueue; // Queue of workers waiting for coffee
	private final ConcurrentLinkedQueue<Coffee> coffeeMachineQueue; // Queue of coffee cups in the machine, starts empty
	private final int maxCoffeeQueueSize = 20; // Maximum number of coffees that can be queued
	private final ReentrantLock lock = new ReentrantLock(); // Lock for thread-safe operations

	public CoffeeMachine(ConcurrentLinkedQueue<Worker> coffeeQueue) {
		this.coffeeQueue = coffeeQueue;
		this.coffeeMachineQueue = new ConcurrentLinkedQueue<>();
	}

	@Override
	public void run() {
		try {
			while (active) {
				// Check if the machine can produce more coffee
				if (coffeeMachineQueue.size() < maxCoffeeQueueSize) {
					produceCoffee(); // Produces coffee if under max capacity
					TimeUnit.SECONDS.sleep(2); // Takes 2 seconds to produce a drink
				}
				// Serve coffee only if there are coffees available in the reserve
				if (!coffeeMachineQueue.isEmpty()) {
					serveCoffee(); // Serve coffee if available
					TimeUnit.SECONDS.sleep(1); // Can serve every second
				}
			}
		} catch (InterruptedException e) {
			System.out.println("Coffee Machine was interrupted.");
			Thread.currentThread().interrupt();
		}
	}

	public void stopMachine() {
		active = false;
	}

	private void produceCoffee() {
		lock.lock(); // Lock to ensure thread safety during production
		try {
			if (coffeeMachineQueue.size() < maxCoffeeQueueSize) { // Check if the coffee machine queue is not full
				Coffee coffee = getRandomCoffee(); // Get a random type of coffee and add it to the queue
				coffeeMachineQueue.add(coffee);
				System.out.println("Produced a " + coffee.getType() + ". Coffee reserve: " + coffeeMachineQueue.size());
			}
		} finally {
			lock.unlock(); // Unlock after coffee production
		}
	}

	private void serveCoffee() {
		lock.lock(); // Lock to ensure thread safety during serving
		try {
			if (!coffeeQueue.isEmpty() && !coffeeMachineQueue.isEmpty()) {
				Worker worker = coffeeQueue.peek(); // Check the worker at the front of the queue
				Coffee coffee = coffeeMachineQueue.poll(); // Remove coffee from the machine queue
				if (worker != null && worker.equals(coffeeQueue.peek())) { // Check if worker is at the front of the
																			// queue
					worker.getcoffee(); // Call getcoffee() function for the worker at the front of the queue
				}
				worker = coffeeQueue.poll(); // Remove worker from the coffee queue
				worker.setEnergyLevel(coffee.getEnergy()); // Set energy level for the worker
				System.out.println(
						worker.getName() + " enjoyed a " + coffee.getType() + " with energy " + coffee.getEnergy());
			}
		} finally {
			lock.unlock(); // Unlock after coffee serving
		}
	}

	private Coffee getRandomCoffee() { // Method to randomly select a type of coffee and create an instance of it
		int rand = (int) (Math.random() * 3); // Generate a random integer between 0 and 2
		switch (rand) { // Switch statement based on the random integer generated
		case 0:
			return new BlackCoffee(); // Return a new instance of BlackCoffee
		case 1:
			return new Capuccino();// Return a new instance of Capuccino
		case 2:
			return new Latte(); // Return a new instance of Latte
		default:
			return null; // Return null(thus never happen)
		}
	}
}
