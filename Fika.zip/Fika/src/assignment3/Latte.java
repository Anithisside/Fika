package assignment3;

// Latte class extending Coffee
public class Latte extends Coffee {

	public Latte() {
		// Passes the type "Latte" and energy range of 25 to 35
		super("LatteDrink", 25, 35);
	}
}
