package assignment3;

//Represents a type of coffee: Black Coffee. 
public class BlackCoffee extends Coffee {

	// Sets the type to "BlackCoffee" and energy levels between 15 and 20.

	public BlackCoffee() {
		super("BlackCoffee", 15, 20);
	}
}