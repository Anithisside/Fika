package assignment3;

// Represents a specific type of coffee: Capuccino
public class Capuccino extends Coffee {

	// Constructs a new Capuccino object with default energy levels.
	// Sets the type to "Capuccino" and energy levels between 20 and 30.
	public Capuccino() {
		super("CappucinoDrink", 20, 30);
	}
}
