package assignment3;

import java.util.Random;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.TimeUnit;

class Worker extends Thread {
	private int timeToLoseEnergy; // Time interval after which energy is decremented
	private ConcurrentLinkedQueue<Worker> coffeeQueue; // Shared queue of workers waiting for coffee
	private volatile int energyLevel; // Current energy level of the worker, can be accessed by multiple threads
	private boolean atWork;
	private final Random random = new Random(); // Random number generator for initial values

	public Worker(String name, ConcurrentLinkedQueue<Worker> coffeeQueue) {
		super(name); // Set the thread (worker) name using the parent class constructor
		this.coffeeQueue = coffeeQueue; // Assign the shared coffee queue
		energyLevel = random.nextInt(61) + 30; // Initialize energy level between 30 and 90
		timeToLoseEnergy = random.nextInt(1001) + 500; // Set time to lose energy between 500ms and 1500ms
	}

	@Override
	public void run() { // Method to start the worker thread.

		try {
			atWork = true;
			while (energyLevel > 0) {
				TimeUnit.MILLISECONDS.sleep(timeToLoseEnergy);

				if (energyLevel < 30) {
					atWork = false;
				} else if (energyLevel > 100) {
					atWork = true;
					System.out.println(this.getName() + " returning to the office with energy level " + energyLevel); // when
																														// energy
																														// exceeds
																														// 100,
																														// the
																														// worker
																														// returns
																														// to
																														// the
																														// office

					return;
				}

				if (atWork) {
					System.out.println(this.getName() + " is working with energy level " + energyLevel); // printing
																											// energy
																											// level
				} else {
					System.out.println(this.getName() + " is waiting for coffee with energylevel " + energyLevel);
					if (energyLevel < 30) {
						goToCoffeeMachine(); // Call the method to go to the CoffeeMachine
					}
					addToCoffeeQueue();
				}
				energyLevel -= 1;
			}
			
		} catch (InterruptedException e) {
			System.out.println("Worker " + getName() + " execution interrupted");
		}
	}

	private void goToCoffeeMachine() { // Method for the worker to go to the coffee machine to get a drink.

		System.out.println(this.getName() + " is going to the CoffeeMachine to get a drink.");
	}

	private void addToCoffeeQueue() { // Method to add the worker to the coffee queue.

		if (!coffeeQueue.contains(this)) {
			coffeeQueue.add(this);
		}
	}

	public int getEnergyLevel() { // method to retrieve the energy level of the worker.

		return energyLevel;
	}

	private void seekCoffee() {
		while (energyLevel < 100 && energyLevel > 0) { // Continue to seek coffee until energy is full or depleted
			synchronized (coffeeQueue) {
				if (!coffeeQueue.contains(this)) {
					coffeeQueue.add(this); // Add to coffee queue if not already in it
					System.out.println(getName() + " is waiting at the coffee machine."); // Print waiting message
				}
			}
			synchronized (this) {
				try {
					while (energyLevel < 100 && energyLevel > 0) {
						wait(); // Wait until notified (usually by receiving coffee)
					}
				} catch (InterruptedException e) {
					Thread.currentThread().interrupt(); // Properly handle thread interruption
					break;
				}
			}
		}
		if (energyLevel >= 100) {
			System.out.println(getName() + " goes back to work with energylevel " + energyLevel); // Go back to work if
																									// energy is full
		}

		// Introducing a delay after drinking before leaving the place for another
		// worker in the queue
		try {
			TimeUnit.SECONDS.sleep(1); // Wait for one second after drinking before leaving
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt(); // Properly handle thread interruption
		}
	}

	private void leaveQueueAndGoHome() {
		synchronized (coffeeQueue) {
			coffeeQueue.remove(this); // Remove from coffee queue when going home
			System.out.println(getName() + " is going home with energy level 0."); // Announce departure
		}
	}

	public synchronized void setEnergyLevel(int energy) {
		this.energyLevel += energy; // Increase energy level by the amount of energy in the consumed coffee
		synchronized (this) {
			notifyAll(); // Notify the worker (wake up from wait) after receiving coffee
		}
	}

	public void getcoffee() {
		// TODO Auto-generated method stub

	}
}
